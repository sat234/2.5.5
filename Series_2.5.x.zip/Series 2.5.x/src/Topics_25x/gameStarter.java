package Topics_25x;

/*
 * Activity 2.5.2
 */
public class gameStarter
{
    public static void main(String[] args)
    {
        Player p = new Player();
        System.out.println(p.getName());
        System.out.println(p.getPoints());
    }
}