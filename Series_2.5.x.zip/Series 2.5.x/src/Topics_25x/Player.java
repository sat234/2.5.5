package Topics_25x;

import java.util.Scanner;

public class Player {
    private String name;
    private double points;

    // Default constructor
    public Player() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a username: ");
        this.name = scanner.nextLine();
        this.points = 0;
        System.out.println(this.name + " is now the player name.");
    }

    // Constructor with a name parameter
    public Player(String inputName) {
        this.name = inputName;
        this.points = 0;
        System.out.println(this.name + ", welcome to phrase solvers. ");
    }

    public String getName() {
        return "\nUser name: " + name;
    }

    public void setName(String x) {
        name = x;
    }

    public String getPoints() {
        return  "Your points: " + points;
    }
}